package com.example.Electricitybill;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectricitybillApplicationTests {

	@Test
	void contextLoads() {
	}

}

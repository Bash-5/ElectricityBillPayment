package com.example.Electricitybill.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.Electricitybill.bean.CustomerBean;

public interface CustomerRepo extends CrudRepository<CustomerBean, String>
{
	List<CustomerBean> findBymobileNumber(String mobileNumber);
	List<CustomerBean> findByemail(String email);
	
} 

package com.example.Electricitybill.bean;
import javax.persistence.Entity;



import javax.persistence.Id;
import javax.persistence.Table;


import java.util.Date;

import lombok.Data;

@Entity
@Table
@Data

public class Connectionbean {
	
	 @Id
     private  long connectionId;
	 private  long consumerNumber;
	  Date applicationDate= new Date();
	  Date connectionDate= new Date();
	 private boolean connectionStatus;
	  
}


package com.example.Electricitybill.dao;
import java.util.List;
import org.springframework.data.repository.CrudRepository;

import com.example.Electricitybill.bean.Billbean;


 public interface Billrepo extends CrudRepository<Billbean,Long> {
	 
	 List<Billbean> findByBillId(long billId);
}


	
	
	

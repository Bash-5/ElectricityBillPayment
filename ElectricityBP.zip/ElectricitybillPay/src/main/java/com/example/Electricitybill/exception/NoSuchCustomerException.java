package com.example.Electricitybill.exception;

public class NoSuchCustomerException extends RuntimeException {
	
		  private static final long serialVersionUID = 1L;


}

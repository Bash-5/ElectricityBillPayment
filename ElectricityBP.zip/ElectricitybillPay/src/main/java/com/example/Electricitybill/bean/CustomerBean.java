package com.example.Electricitybill.bean;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Table
@Data

public class CustomerBean {
	
	@Id
	private long customerId;
	private long addharNumber;
	private String firstName;
	private String lastName;
	private String middleName;
	private String mobileNumber;
	private String email;
	private String gender;

}

package com.example.Electricitybill.dao;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.Electricitybill.bean.Connectionbean;


public interface ConnectionRepo extends CrudRepository<Connectionbean, Long>
{
	List<Connectionbean> findByconsumerNumber(Long consumerNumber);
	
} 
